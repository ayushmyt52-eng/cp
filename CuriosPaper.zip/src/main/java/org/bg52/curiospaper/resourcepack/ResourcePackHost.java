package org.bg52.curiospaper.resourcepack;

public interface ResourcePackHost {
    void start();

    void stop();

    int getPort();
}
